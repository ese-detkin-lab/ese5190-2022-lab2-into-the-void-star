#include <stdio.h>
#include <stdlib.h>

#ifndef _WS2812_H
#define _WS2812_H

void set_color(int color_change);

#endif