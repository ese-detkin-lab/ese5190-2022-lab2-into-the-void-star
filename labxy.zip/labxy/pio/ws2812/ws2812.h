#ifndef _WS2812_H
#define _WS2812_H


void turn_on_pixelpower();
void set_neopixel_color(uint32_t color);
void rp_init();

#endif