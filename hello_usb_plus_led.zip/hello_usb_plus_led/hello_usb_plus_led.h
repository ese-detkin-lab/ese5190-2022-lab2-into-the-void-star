#ifndef _WS2812_H
#define _WS2812_H
void set_neopixel_color(uint32_t color); #endif

void set_neopixel_color(int t1, int t2, int t3) { // your implementation goes here
    color = urgb_u32(0xDA+t1, 0x70+t2, 0xD6+t3);
}